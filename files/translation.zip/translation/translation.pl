
$flag = "n5b2019summer{******************************}";
$a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
$b = "VOxbkTqczsedDBv8PoN0JGny4Q1tAr35XKC6Y7pHFMWLajfR2EmhiZgl9uSIUw";

for($i = 0; $i < 50; $i++)
{
  $r = rand 50;
  $b = substr($b, $r) . substr($b, 0, $r);
}


eval "\$flag =~ y/$a/$b/";
print "$flag\n";
